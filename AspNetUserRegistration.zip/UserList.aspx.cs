using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;

namespace WebApp
{
    public partial class UserList : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                var users = Application["RegisteredUsers"] as List<User>;
                if (users != null)
                {
                    var indexedUsers = users.Select((u, index) => new
                    {
                        Index = index + 1,
                        u.FirstName,
                        u.LastName,
                        u.Email,
                        u.Gender,
                        u.Role
                    }).ToList();

                    GridViewUsers.DataSource = indexedUsers;
                    GridViewUsers.DataBind();
                }
            }
        }
    }
}