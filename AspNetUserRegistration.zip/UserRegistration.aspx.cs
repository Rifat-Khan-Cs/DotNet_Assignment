using System;
using System.Collections.Generic;
using System.Web.UI;

namespace WebApp
{
    public partial class UserRegistration : Page
    {
        protected void btnRegister_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                var user = new User
                {
                    FirstName = txtFirstName.Text,
                    LastName = txtLastName.Text,
                    Email = txtEmail.Text,
                    Gender = rblGender.SelectedValue,
                    Role = ddlRole.SelectedValue
                };

                var users = Application["RegisteredUsers"] as List<User> ?? new List<User>();
                users.Add(user);
                Application["RegisteredUsers"] = users;

                Response.Redirect("UserList.aspx");
            }
        }
    }

    public class User
    {
        public string FirstName;
        public string LastName;
        public string Email;
        public string Gender;
        public string Role;
    }
}