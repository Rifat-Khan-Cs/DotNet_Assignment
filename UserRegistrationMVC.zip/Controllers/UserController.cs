using System.Collections.Generic;
using System.Web;
using System.Web.Mvc;
using WebApp.Models;

namespace WebApp.Controllers
{
    public class UserController : Controller
    {
        public ActionResult Register()
        {
            ViewBag.Roles = new List<string> { "Admin", "Manager", "Employee" };
            return View();
        }

        [HttpPost]
        public ActionResult Register(User user)
        {
            ViewBag.Roles = new List<string> { "Admin", "Manager", "Employee" };
            if (ModelState.IsValid)
            {
                var users = HttpContext.Application["RegisteredUsers"] as List<User> ?? new List<User>();
                users.Add(user);
                HttpContext.Application["RegisteredUsers"] = users;
                return RedirectToAction("List");
            }
            return View(user);
        }

        public ActionResult List()
        {
            var users = HttpContext.Application["RegisteredUsers"] as List<User> ?? new List<User>();
            return View(users);
        }
    }
}
